
Umask Lab
---------
Change umask values and observe how file permissions are affected.
