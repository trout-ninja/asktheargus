
Setgid & Sticky Bit Lab
----------------------
Create a shared directory and experiment with:
- setgid inheritance
- sticky bit deletion rules
