# Section 14 — Processes & Job Control (Expanded)

This directory adds hands-on material for **LFS207 Section 14: Processes**.

## Core concepts you will practice

- Process identity: **PID**, **PPID**, process groups, sessions
- Seeing processes: `ps`, `pstree`, `top`, `pgrep`, `pidof`
- Process state: running/sleeping/stopped/zombie (where applicable)
- Signals: `SIGTERM`, `SIGINT`, `SIGHUP`, `SIGKILL`, `SIGSTOP`, `SIGCONT`
- Job control (interactive shells): background `&`, `Ctrl+Z`, `jobs`, `fg`, `bg`, `disown`
- Priorities: `nice`, `renice`
- Long-running sessions: `nohup` (and why it differs from `disown`)

## Start here

1. Read: `labs/mission_processes.md`
2. Run: `samples/spawn_tree.sh` and observe with `ps` / `pstree`
3. Practice signals with `samples/signal_target.sh`
