# Mission — Processes (Section 14)

## Mission 14A — Observe process identity (5–10 minutes)

1) In a terminal:
- Run `echo $$` (PID of your current shell)
- Run `ps -o pid,ppid,pgid,sid,tty,stat,cmd -p $$`

Write down:
- What are **PPID**, **PGID**, **SID** for your shell?

2) Start a subshell:
- `bash`
- Re-run the `echo $$` and `ps ...` command.

Write down:
- What changed? What stayed the same?

---

## Mission 14B — Build a process tree (10 minutes)

Run:
- `bash samples/spawn_tree.sh`

In another terminal (or same, after it starts):
- `ps -ef | grep spawn_tree`
- `pstree -p | less` (or `pstree -p <PID>` if you have it)
- `pgrep -af spawn_tree`

Write down:
- How many processes are created?
- Which are children of which?

---

## Mission 14C — Signals and states (10 minutes)

Run:
- `bash samples/signal_target.sh`

In another terminal:
- Find the PID: `pgrep -af signal_target`
- Send `SIGTERM`: `kill <PID>`
- Restart the script, then send `SIGKILL`: `kill -9 <PID>`

Write down:
- What difference do you observe in behavior/output?

Stretch:
- Try `SIGSTOP` then `SIGCONT`:
  - `kill -STOP <PID>`
  - `kill -CONT <PID>`

---

## Mission 14D — Job control is shell-local (10 minutes)

In an interactive shell:

1) Start a background job:
- `sleep 120 &`
- `jobs`

2) Stop a foreground job:
- `sleep 120`
- press `Ctrl+Z`
- `jobs`
- `bg`
- `jobs`
- `fg`

3) Now prove it is shell-local:
- Start a subshell: `bash`
- Run `jobs` (should be empty)
- Exit and run `jobs` again in the parent shell.

Write down:
- Why does `jobs` differ between shells?

---

## Mission 14E — nice / renice (optional, 10 minutes)

Run CPU load (if `yes` is available):
- `yes > /dev/null &`
- `ps -o pid,ni,cmd -p $!`

Change priority:
- `renice 10 -p <PID>`
- Check with `ps -o pid,ni,cmd -p <PID>`

Clean up:
- `kill <PID>`

Write down:
- What does NI change, and what does it *not* guarantee?
