#!/usr/bin/env bash
set -euo pipefail

# Spawns a small process tree for observation.
# Run this, then inspect with: ps, pstree, pgrep.

echo "[spawn_tree] Parent PID: $$"

child() {
  local name="$1"
  echo "[spawn_tree] Child $name PID: $$ (PPID: $PPID)"
  # Keep the child alive for a bit so you can observe it
  sleep 90
}

# Two children, one of which spawns a grandchild.
(
  child "A"
) &

(
  echo "[spawn_tree] Child B PID: $$ (PPID: $PPID)"
  (
    echo "[spawn_tree] Grandchild B1 PID: $$ (PPID: $PPID)"
    sleep 90
  ) &
  sleep 90
) &

echo "[spawn_tree] Spawned children. Use 'jobs' to see them in this shell."
wait
