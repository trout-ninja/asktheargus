#!/usr/bin/env bash
set -euo pipefail

# A simple long-running process that prints status so you can observe signals.
# Start it, then send signals from another terminal:
#   pgrep -af signal_target
#   kill <PID>
#   kill -9 <PID>
#   kill -STOP <PID>; kill -CONT <PID>

echo "[signal_target] PID: $$ (PPID: $PPID)"
trap 'echo "[signal_target] Caught SIGINT (Ctrl+C)"; exit 130' INT
trap 'echo "[signal_target] Caught SIGTERM"; exit 143' TERM
trap 'echo "[signal_target] Caught SIGHUP"; exit 129' HUP

i=0
while true; do
  i=$((i+1))
  echo "[signal_target] tick=$i  time=$(date +%T)"
  sleep 2
done
