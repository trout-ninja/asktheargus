
Networking Fundamentals
-----------------------
ip, ss, ping, resolvectl exercises.
