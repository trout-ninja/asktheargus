
LFS207 Sandbox — Sections 1–14
=============================

This sandbox is designed to practice concepts from Linux Foundation LFS207
up through Section 14.

Topics covered:
- Users and groups
- Permissions, umask, setuid/setgid, sticky bit
- Process control and job management
- systemd basics
- Networking fundamentals
- Storage and mounts
- Archives and logs

IMPORTANT:
Run all setup scripts inside a VM.
Some exercises intentionally create insecure configurations.
