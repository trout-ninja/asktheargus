
Mission Set — LFS207 Sections 1–14
=================================

Mission 1: Users & Groups
- Create users alice, bob, charlie
- Create groups sandboxers, ops
- Verify /etc/passwd and /etc/group

Mission 2: umask
- Set umask to 077
- Create files and observe permissions

Mission 3: setgid Directories
- Apply setgid to a shared directory
- Observe group inheritance

Mission 4: Sticky Bit
- Apply sticky bit
- Verify deletion restrictions

Mission 5: Job Control
- Use &, jobs, fg, bg
- Observe behavior across subshells

Mission 6: Signals
- Send SIGTERM and SIGKILL
- Observe process states

Mission 7: systemd
- Inspect running services
- Enable and disable a service

Mission 8: Networking
- Inspect interfaces
- Check routes and DNS

Mission 9: Storage
- Mount a loopback filesystem
- Verify persistence

Mission 10: Archives
- Create tarballs
- Extract with permissions preserved

Mission 11: Logs
- Inspect journald
- Filter logs by unit and time

Mission 12–14:
- Integrated troubleshooting challenges


---
## Section 14 (Expanded): Processes

See: `processes_jobs/labs/mission_processes.md`

- Mission 14A: Process identity (PID/PPID/PGID/SID)
- Mission 14B: Process tree observation (ps/pstree/pgrep)
- Mission 14C: Signals and states (TERM/KILL/STOP/CONT)
- Mission 14D: Job control is shell-local (jobs/fg/bg/Ctrl+Z)
- Mission 14E: nice/renice (optional)
