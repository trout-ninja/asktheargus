
Archives & Logs
---------------
tar, gzip, journalctl exercises.
