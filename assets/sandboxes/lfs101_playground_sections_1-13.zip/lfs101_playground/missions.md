# LFS101 Playground (Sections 1–13) — Beginner-Friendly Missions

**Scope:** LFS101 Sections 1–13 (up through Git Fundamentals)  
**Do not** use Process tools (Section 14) unless a mission explicitly mentions them (none do).

## Setup & Rules

1. Run the setup script **as root** on your Rocky VM:

```bash
sudo bash setup.sh
```

2. Then work as a normal user. Recommended:

```bash
su - argus_alex
```

3. Playground root directory:

```bash
cd /srv/lfs101-playground
```

---

## Mission 0 — Orientation

**Objective:** Confirm you are in the right place and understand what exists.

**Do:**
- Print your current directory.
- List the top-level folders under `/srv/lfs101-playground`.
- Read `notes/ONBOARDING.txt`.

**Success looks like:**
- You can explain what each top-level directory likely contains.

---

## Mission 1 — Find the Key (navigation + search)

**Objective:** Find a file named `argus_key.txt` somewhere under the playground and print its contents.

**Constraints:**
- Do not move or edit the file.

**Success looks like:**
- You can display the key in the terminal.
- You can tell me the command(s) you used.

**Hints if stuck:**
- `find` is your friend.

---

## Mission 2 — “I should be able to write here” (users, groups, permissions)

**Objective:** As `argus_alex`, create a file in `/srv/lfs101-playground/projects/`:

```bash
touch /srv/lfs101-playground/projects/alex.txt
```

**Expected problem:** It will fail initially.

**Your job:**
- Diagnose *why* it fails using `ls -ld`, `id`, and group checks.
- Apply the **minimum** fix so members of `argus_dev` can create files there.

**Success looks like:**
- `argus_alex` can create `alex.txt`
- `argus_bea` can also create `bea.txt`
- The directory is still not world-writable

---

## Mission 3 — Safe dropzone (sticky bit)

**Objective:** `/srv/lfs101-playground/dropzone` should allow anyone to drop files, **but not delete other people’s files**.

**Current state:** It is world-writable but unsafe.

**Your job:**
- Apply the correct permission change.

**Success looks like:**
- Permissions show `t` in the mode string.
- You can explain what the sticky bit does in one sentence.

---

## Mission 4 — umask and “unexpected” permissions

**Objective:** Run the artifact script and interpret the permissions.

```bash
/srv/lfs101-playground/bin/make_artifact.sh
```

**Your job:**
- Explain why the created file has the permissions it has.
- Adjust behavior so the created artifact is readable by the `argus_dev` group (but not world-readable).

**Constraints:**
- Do **not** make it world-readable.
- Prefer a fix that does not permanently weaken your system defaults.

**Success looks like:**
- The resulting file shows group-read permissions (`r--` for group at minimum).
- You can explain the role of `umask`.

---

## Mission 5 — Redirection basics (write output to a file)

**Objective:** Capture a directory listing to a file under `tmp/`.

**Do:**
- Make sure `/srv/lfs101-playground/tmp/` exists.
- Redirect the output of `ls -l /srv/lfs101-playground` to `tmp/ls.txt`.

**Success looks like:**
- `tmp/ls.txt` exists and contains the listing.

---

## Mission 6 — Pipes (filter a log)

**Objective:** From `logs/noisy.log`, extract only the WARN lines into `tmp/warn.txt`.

**Success looks like:**
- `tmp/warn.txt` contains only WARN entries.

**Hints if stuck:**
- `grep` + pipe + redirection.

---

## Mission 7 — Edit a config file (nano-safe)

**Objective:** Change the app mode from `production` to `staging` in:

`/srv/lfs101-playground/config/app.conf`

**Success looks like:**
- `MODE=staging` appears in the file.
- You can tell me how you saved and exited your editor.

---

## Mission 8 — Environment variables (session scope)

**Objective:** Run the report generator:

```bash
/srv/lfs101-playground/bin/run_report.sh
```

**Expected problem:** It will fail because an env var is missing.

**Your job:**
- Set the required variable **for your current shell session**
- Re-run successfully
- Verify the report file exists

**Success looks like:**
- `/srv/lfs101-playground/tmp/report.txt` exists and has a timestamp line.

---

## Mission 9 — “It exists, but I can’t run it” (PATH + execute)

**Objective:** Run `argus-tool`.

**Expected problems:**
- It is **not** in your PATH
- It is **not** executable

**Your job:**
1. Locate the file.
2. Make it executable.
3. Run it.
4. (Optional) Make it runnable by name without typing the full path (temporary is fine).

**Success looks like:**
- Running it prints `argus-tool: ok`.

---

## Mission 10 — Git Fundamentals (status, add, commit)

Go here:

```bash
cd /srv/lfs101-playground/site
```

**Objective:** Clean up the repo properly.

**Repo is currently:**
- Modified tracked file (`index.html`)
- Untracked file (`TODO.txt`)
- Ignored content (`build/`, `secrets.env`)

**Your job:**
1. Inspect repo status.
2. Stage and commit the intended changes:
   - Commit `index.html` change
   - Add and commit `TODO.txt`
3. Confirm ignored files are not staged.

**Success looks like:**
- `git status` shows a clean working tree.
- You can show `git log --oneline -n 3`.

---

## After you finish

Send me:
- Which mission was hardest
- The exact command(s) you used for Mission 2 and Mission 10
- Any “huh?” moments

Then you will be ready to start **Section 14: Processes** with much less friction.
