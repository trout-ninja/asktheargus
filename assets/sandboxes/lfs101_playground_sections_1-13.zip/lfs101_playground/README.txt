LFS101 Playground (Sections 1–13)

Files:
- setup.sh      : run as root to create the playground
- missions.md   : your mission list (work as a normal user)

Quick start:
  sudo bash setup.sh
  su - argus_alex
  less /srv/lfs101-playground/missions.md
