#!/usr/bin/env bash
# LFS101 Playground Setup (Sections 1–13)
# Target OS: Rocky Linux / RHEL-family
# Safe: Creates files under /srv/lfs101-playground and a few users/groups.

set -euo pipefail

PLAYROOT="/srv/lfs101-playground"
USERS=(argus_alex argus_bea argus_cai)
GROUPS=(argus_dev argus_ops)

need_root() {
  if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    echo "ERROR: Run as root (or via sudo). Example: sudo bash setup.sh"
    exit 1
  fi
}

ensure_pkg_git() {
  if command -v git >/dev/null 2>&1; then
    return 0
  fi
  echo "NOTICE: git not found. Install it with:"
  echo "  sudo dnf -y install git"
  echo "Then re-run this setup script."
  exit 2
}

create_groups_users() {
  for g in "${GROUPS[@]}"; do
    if ! getent group "$g" >/dev/null 2>&1; then
      groupadd "$g"
    fi
  done

  for u in "${USERS[@]}"; do
    if ! id "$u" >/dev/null 2>&1; then
      useradd -m -s /bin/bash "$u"
      echo "${u}:argus" | chpasswd
      passwd -e "$u" >/dev/null 2>&1 || true
    fi
  done

  # Memberships (intentionally imperfect for one mission)
  usermod -aG argus_dev argus_alex
  usermod -aG argus_dev argus_bea
  usermod -aG argus_ops argus_cai
}

reset_tree() {
  rm -rf "$PLAYROOT"
  mkdir -p "$PLAYROOT"
  mkdir -p "$PLAYROOT"/{projects,logs,config,bin,site,notes,dropzone,tmp}
}

seed_files() {
  # Notes & navigation/search content
  cat >"$PLAYROOT/notes/ONBOARDING.txt" <<'EOF'
Welcome to Ask the Argus internal lab.

If you're new here:
- Start with missions.md
- Work as a normal user unless a mission explicitly tells you to use sudo/root.

Cheat-sheet hints are allowed, but try to reason first.

EOF

  cat >"$PLAYROOT/notes/where_is_the_key.txt" <<'EOF'
Somewhere in this tree is a small file named:
  argus_key.txt

Find it. Read it. Do not move it.

EOF

  mkdir -p "$PLAYROOT/notes/archive/2024" "$PLAYROOT/notes/archive/2025"
  echo "old memo" > "$PLAYROOT/notes/archive/2024/memo_old.txt"
  echo "new memo" > "$PLAYROOT/notes/archive/2025/memo_new.txt"
  echo "ARGUS{search_success}" > "$PLAYROOT/notes/archive/2025/argus_key.txt"
  touch -d "2025-12-20 10:00:00" "$PLAYROOT/notes/archive/2025/memo_new.txt" || true

  # Config file for editor mission
  cat >"$PLAYROOT/config/app.conf" <<'EOF'
# Argus App Configuration
MODE=production
PORT=8080
LOG_LEVEL=info
EOF

  # Noisy log for pipe/redirection missions
  cat >"$PLAYROOT/logs/noisy.log" <<'EOF'
2025-12-27 10:02:01 INFO  server Started successfully
2025-12-27 10:02:02 WARN  auth   Failed login for user=admin ip=10.0.0.55
2025-12-27 10:02:05 INFO  auth   Login ok user=argus_alex ip=10.0.0.12
2025-12-27 10:03:11 ERROR db     Connection timeout
2025-12-27 10:03:14 INFO  server Healthcheck ok
2025-12-27 10:04:09 WARN  auth   Failed login for user=root ip=10.0.0.77
2025-12-27 10:05:44 INFO  jobs   Completed batch=nightly-1
2025-12-27 10:06:02 ERROR api    500 on /submit
EOF

  # A script that creates files with an "unexpected" umask result
  cat >"$PLAYROOT/bin/make_artifact.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

# This script intentionally sets a restrictive umask.
# Mission: diagnose what it does and adjust the behavior safely.
umask 0077

outdir="${1:-/srv/lfs101-playground/projects}"
mkdir -p "$outdir"
echo "artifact $(date -Is)" > "$outdir/artifact.txt"
echo "Created: $outdir/artifact.txt"
ls -l "$outdir/artifact.txt"
EOF

  # Env var dependent script
  cat >"$PLAYROOT/bin/run_report.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

# This script expects ARGUS_HOME to be set.
: "${ARGUS_HOME:?ARGUS_HOME is not set. Example: export ARGUS_HOME=/srv/lfs101-playground}"

if [[ ! -d "$ARGUS_HOME" ]]; then
  echo "ARGUS_HOME points to a non-existent directory: $ARGUS_HOME"
  exit 3
fi

echo "Report generated at: $ARGUS_HOME/tmp/report.txt"
mkdir -p "$ARGUS_HOME/tmp"
echo "OK $(date -Is)" > "$ARGUS_HOME/tmp/report.txt"
EOF

  # A "tool" placed off-PATH and also missing execute bit (two small issues)
  mkdir -p /opt/argus/bin
  cat >/opt/argus/bin/argus-tool <<'EOF'
#!/usr/bin/env bash
echo "argus-tool: ok"
EOF
  chmod 0644 /opt/argus/bin/argus-tool  # intentionally not executable

  # Git repo for fundamentals mission
  pushd "$PLAYROOT/site" >/dev/null
  git init -q
  cat > index.html <<'EOF'
<!doctype html>
<html>
  <head><meta charset="utf-8"><title>Argus Site</title></head>
  <body>
    <h1>Ask the Argus</h1>
    <p>Status: draft</p>
  </body>
</html>
EOF
  printf "build/\nsecrets.env\n" > .gitignore
  git add index.html .gitignore
  git commit -q -m "Initial site skeleton"

  # Create "dirty" state
  sed -i 's/Status: draft/Status: staging/' index.html
  echo "TEMP=1" > secrets.env           # should be ignored
  echo "notes for later" > TODO.txt     # untracked
  mkdir -p build && echo "artifact" > build/out.txt  # ignored folder
  popd >/dev/null

  # A small permissions lab: shared directory set up *almost* right but not usable
  chown -R root:argus_dev "$PLAYROOT/projects"
  chmod 0755 "$PLAYROOT/projects"  # group can't write (mission fix)

  # Dropzone: should allow everyone to drop files safely, but currently unsafe
  chmod 0777 "$PLAYROOT/dropzone"  # missing sticky bit (mission fix)

  # Logs readable but not writable (fine), config readable, scripts executable (except the tool)
  chown -R root:root "$PLAYROOT/logs" "$PLAYROOT/config" "$PLAYROOT/notes" "$PLAYROOT/site"
  chmod 0755 "$PLAYROOT/bin"
  chmod 0755 "$PLAYROOT/bin/"*.sh

  # Make logs readable to all
  chmod 0644 "$PLAYROOT/logs/noisy.log"
}

final_message() {
  cat <<EOF

Setup complete.

Playground root:
  $PLAYROOT

Users created (password will be forced to change on first login):
  ${USERS[*]}

Groups:
  ${GROUPS[*]}

Next:
  1) Read missions:  less $PLAYROOT/missions.md
  2) Work primarily as a normal user (e.g., argus_alex)
  3) Use sudo/root only when a mission requires it

EOF
}

main() {
  need_root
  ensure_pkg_git
  create_groups_users
  reset_tree
  seed_files
  final_message
}

main "$@"
