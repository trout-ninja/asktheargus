# Curveball: “I set ulimit -n 65535 but it didn’t work”

This comes up constantly. Some common explanations:

1) **You changed the wrong context**
   - `ulimit` affects the current shell and its children only.
   - A GUI app you launch from a menu may not be a child of that terminal.

2) **You hit the hard limit**
   - You can raise soft to hard, but raising hard usually requires privileges.

3) **systemd overrides**
   - systemd services can set `LimitNOFILE=...` in the unit file.
   - system-wide defaults can be set via `DefaultLimitNOFILE=` in systemd config.

4) **PAM limits are not applied**
   - If `pam_limits.so` isn't enabled for your login/session, `limits.conf` is ignored.

5) **App-level limits**
   - Some programs set their own rlimits early at startup.

Your task: explain at least three of these in your own words, using your machine’s evidence where possible.
