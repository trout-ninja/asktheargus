#!/usr/bin/env bash
set -euo pipefail

echo "Parent PID: $$"
echo
echo "ulimit -Sn (soft nofile): $(ulimit -Sn)"
echo "ulimit -Hn (hard nofile): $(ulimit -Hn)"
echo "ulimit -St (soft cpu time): $(ulimit -St)"
echo "ulimit -Ss (soft stack KB): $(ulimit -Ss 2>/dev/null || echo N/A)"
echo
echo "Kernel view (/proc/$$/limits):"
grep -E 'Max open files|Max processes|Max stack size|Max cpu time' /proc/$$/limits || true
echo
echo "Launching a child process to show inheritance..."
bash -c '
  echo " Child PID: $$"
  echo " Child ulimit -Sn: $(ulimit -Sn)"
  echo " Child ulimit -Hn: $(ulimit -Hn)"
  echo " Child /proc/$$/limits (selected):"
  grep -E "Max open files|Max processes|Max stack size|Max cpu time" /proc/$$/limits || true
'
