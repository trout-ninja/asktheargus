#!/usr/bin/env bash
set -euo pipefail

SECONDS=5
if [[ "${1:-}" == "--seconds" ]]; then
  SECONDS="${2:-5}"
fi

echo "Busy-looping for ~${SECONDS}s of wall time (consumes CPU)."
python3 - <<'PY'
import time, sys
secs = float(sys.argv[1])
end = time.time() + secs
x = 0
while time.time() < end:
    x = (x * 1664525 + 1013904223) & 0xFFFFFFFF
print("done", x)
PY "${SECONDS}"
