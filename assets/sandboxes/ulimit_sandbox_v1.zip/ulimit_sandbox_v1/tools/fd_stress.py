#!/usr/bin/env python3
import argparse, os, sys, tempfile, json

STATE = os.path.join(os.path.dirname(__file__), "..", "state", "fd_stress_state.json")
STATE = os.path.abspath(STATE)

def ensure_dirs():
    os.makedirs(os.path.dirname(STATE), exist_ok=True)

def cleanup():
    if not os.path.exists(STATE):
        print("No state file found; nothing to clean.")
        return 0
    with open(STATE, "r", encoding="utf-8") as f:
        data = json.load(f)
    paths = data.get("paths", [])
    removed = 0
    for p in paths:
        try:
            os.remove(p)
            removed += 1
        except FileNotFoundError:
            pass
        except Exception as e:
            print(f"Could not remove {p}: {e}")
    try:
        os.remove(STATE)
    except Exception:
        pass
    print(f"Cleanup complete. Removed {removed} temp files.")
    return 0

def main():
    ap = argparse.ArgumentParser(description="Open many files to demonstrate RLIMIT_NOFILE behavior safely.")
    ap.add_argument("--target", type=int, default=500, help="How many files to try to open.")
    ap.add_argument("--keep", action="store_true", help="Keep temp files so you can inspect them; cleanup later.")
    ap.add_argument("--cleanup", action="store_true", help="Remove kept temp files from prior runs.")
    args = ap.parse_args()

    ensure_dirs()

    if args.cleanup:
        return cleanup()

    # Create a temp directory inside sandbox state/
    temp_dir = os.path.join(os.path.dirname(STATE), "tmpfiles")
    os.makedirs(temp_dir, exist_ok=True)

    fds = []
    paths = []
    fail_at = None

    for i in range(args.target):
        path = os.path.join(temp_dir, f"fd_{i:05d}.tmp")
        try:
            # open file and keep descriptor open
            fd = open(path, "w", encoding="utf-8")
            fd.write("x")
            fd.flush()
            fds.append(fd)
            paths.append(path)
        except OSError as e:
            fail_at = i
            print(f"FAILED at i={i}: {e}")
            break

    opened = len(fds)
    print(f"Opened {opened} file descriptors (target={args.target}).")

    if args.keep:
        with open(STATE, "w", encoding="utf-8") as f:
            json.dump({"paths": paths}, f)
        print(f"Kept temp files. Cleanup later with: python3 tools/fd_stress.py --cleanup")
    else:
        # Close and remove temp files immediately
        for fd in fds:
            try: fd.close()
            except Exception: pass
        for p in paths:
            try: os.remove(p)
            except Exception: pass
        # Try to remove temp dir if empty
        try: os.rmdir(temp_dir)
        except Exception: pass
        print("Cleaned up temp files automatically.")

    if fail_at is not None:
        return 2
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
