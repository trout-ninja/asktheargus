#!/usr/bin/env python3
import argparse, sys
sys.setrecursionlimit(10_000_000)

def recurse(n):
    if n <= 0:
        return 0
    return 1 + recurse(n-1)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--depth", type=int, default=20000)
    args = ap.parse_args()
    print(f"Attempting recursion depth={args.depth}")
    try:
        r = recurse(args.depth)
        print("SUCCESS:", r)
        return 0
    except RecursionError as e:
        print("RecursionError:", e)
        return 3

if __name__ == "__main__":
    raise SystemExit(main())
