# Missions: ulimit / resource limits

## Mission 0 — Baseline inventory (no changes)

1) In a terminal, capture your current limits:

```bash
ulimit -a
```

2) Compare with what the kernel reports for your shell:

```bash
cat /proc/$$/limits
```

Write down:
- Max open files (`nofile`)
- Max processes (`nproc`)
- Stack size
- Core file size
- CPU time

**Deliverable:** create `notes/baseline.txt` with a short summary of 5 limits.

---

## Mission 1 — Soft vs hard (the “two ceilings” model)

1) Display your soft and hard open-file limits:

```bash
ulimit -Sn
ulimit -Hn
```

2) Lower your **soft** open-file limit to 128 and verify:

```bash
ulimit -Sn 128
ulimit -Sn
ulimit -Hn
```

3) In the same shell, try to raise the soft limit above the hard limit (expect failure):

```bash
ulimit -Sn 999999
```

**Deliverable:** add a paragraph to `notes/baseline.txt` describing soft vs hard in your own words.

---

## Mission 2 — Demonstrate a real failure: file descriptors

Run the tool that tries to open many files:

```bash
python3 tools/fd_stress.py --target 500 --keep
```

It should fail when your soft limit is low.

Now raise your soft limit (within the hard limit), and rerun:

```bash
ulimit -Sn 1024
python3 tools/fd_stress.py --target 500 --keep
```

Then clean up:

```bash
python3 tools/fd_stress.py --cleanup
```

**Deliverable:** paste the “failure point” and “success point” into `notes/fd_test.txt`.

---

## Mission 3 — Limits are inherited (parent → child)

1) Set a low soft nofile again:

```bash
ulimit -Sn 128
```

2) Run the child-check script:

```bash
bash tools/show_limits_child.sh
```

Observe the child sees the same limits.

3) Open a new terminal (or start a clean shell) and confirm your default differs.

**Deliverable:** In `notes/inheritance.txt`, explain why a new terminal helps recover from a bad ulimit setting.

---

## Mission 4 — CPU time limit (safe version)

Run:

```bash
bash tools/cpu_spin.sh --seconds 5
```

Now set a CPU time limit of 1 second and rerun:

```bash
ulimit -St 1
bash tools/cpu_spin.sh --seconds 5
echo $?
```

Interpret the exit code and the behavior.

Reset CPU limit (or open a new shell if needed).

**Deliverable:** `notes/cpu_time.txt` describing what happened.

---

## Mission 5 — Stack size and recursion (optional)

View stack limits:

```bash
ulimit -Ss
ulimit -Hs
```

Run the recursion test:

```bash
python3 tools/stack_recursion.py --depth 20000
```

Now lower your soft stack size and rerun:

```bash
ulimit -Ss 256
python3 tools/stack_recursion.py --depth 20000
```

Reset by starting a new shell.

**Deliverable:** `notes/stack.txt` with results.

---

## Mission 6 — Where do defaults come from? (inspection)

On many distros, login/session limits can be influenced by:
- `/etc/security/limits.conf` and `/etc/security/limits.d/*`
- PAM module: `pam_limits.so`
- systemd (user sessions), e.g. `DefaultLimitNOFILE=...`

Without changing anything, **inspect**:

```bash
ls -la /etc/security/limits.conf /etc/security/limits.d 2>/dev/null || true
grep -R "pam_limits" /etc/pam.d 2>/dev/null || true
systemctl show --property DefaultLimitNOFILE 2>/dev/null || true
systemctl show --property DefaultLimitNPROC  2>/dev/null || true
```

Compare what you find to the sample excerpts in `samples/`.

**Deliverable:** `notes/sources.txt` listing which of the above exist on your machine and one sentence for each about what it does.

---

## Mission 7 — Curveball: why does “ulimit -n 65535” sometimes “not work”?

Read `samples/curveball.md`.

Then explain (in `notes/curveball.txt`) at least **three** reasons why a change may not take effect:
- wrong context (wrong shell / non-interactive)
- hard limit / privilege boundary
- systemd service limit overrides
- application-level limits
- container/VM constraints

---

## Done

When complete, you should have:
- `notes/baseline.txt`
- `notes/fd_test.txt`
- `notes/inheritance.txt`
- `notes/cpu_time.txt`
- `notes/stack.txt` (optional)
- `notes/sources.txt`
- `notes/curveball.txt`
