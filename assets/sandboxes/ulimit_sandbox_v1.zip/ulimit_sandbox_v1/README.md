# ulimit Sandbox (v1)

This sandbox is a hands-on lab to understand **ulimit / resource limits** in Linux.

You will practice:
- Inspecting limits (shell + /proc)
- Understanding **soft vs hard** limits
- Raising/lowering limits safely
- Seeing how limits affect real programs (file descriptors, stack, CPU time)
- Learning where persistent limits come from (PAM limits, systemd, login sessions)

## Quick start

From the directory you extracted:

```bash
cd ulimit_sandbox_v1
less missions/01_missions.md
```

You will run commands in your **current shell**. Some optional missions require `sudo` to inspect system config.
Nothing in this sandbox requires you to permanently change your OS.

## Safety notes

- Do **not** run random “fork bomb” commands. This sandbox does not use them.
- If you set very low limits, open a **new terminal** to recover.
- If you get stuck, read: `hints/hints.md` then `solutions/solutions.md`.

## Folder map

- `missions/`   — what to do
- `tools/`      — scripts that demonstrate limits
- `samples/`    — sample outputs & config excerpts (for reference)
- `hints/`      — guidance
- `solutions/`  — one possible solution path
