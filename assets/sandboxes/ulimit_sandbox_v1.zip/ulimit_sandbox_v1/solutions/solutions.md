# Solutions (one possible path)

These are not the only solutions. Use them to check your understanding.

## Mission 0
- `ulimit -a` plus `/proc/$$/limits` should agree (format differs).

## Mission 1
- Soft limit can be lowered freely.
- Soft can be raised up to hard.
- Raising hard typically requires privileges (root or CAP_SYS_RESOURCE), and even then may be bounded.

## Mission 2
- With `ulimit -Sn 128`, `fd_stress.py --target 500 --keep` should fail with an error like:
  - `OSError: [Errno 24] Too many open files`
- Raising to 1024 should let 500 succeed.

## Mission 3
- Child inherits parent rlimits: your subshell/script will match the current shell.
- New terminal starts a new login/session and usually begins with default limits again.

## Mission 4
- `ulimit -St 1` sets CPU time soft limit to 1 second.
- Busy loop should be terminated by the kernel (SIGXCPU). Exit code often 137/152 depending on shell reporting.

## Mission 5
- Python recursion may hit Python’s recursion limit before stack; the script raises recursion limit.
- Lowering stack can trigger a crash or segmentation fault depending on distro/kernel/python build.

## Mission 6
- If `/etc/security/limits.conf` exists, it is the traditional place for per-user limits.
- `pam_limits.so` must be referenced in PAM config for limits.conf to apply.
- systemd `DefaultLimitNOFILE` affects services and sometimes user sessions.

## Mission 7
Common reasons:
1) You raised soft but forgot the hard limit ceiling.
2) You changed a shell but your process runs as a systemd service with its own `LimitNOFILE=`.
3) You are in a container/VM with capped rlimits.
4) You edited limits.conf but PAM limits is not enabled for that session type.
