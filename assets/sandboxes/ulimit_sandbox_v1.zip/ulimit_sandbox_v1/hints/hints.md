# Hints

## Big picture
- `ulimit` is a **shell builtin** (bash/zsh). It changes limits **for the current shell process** and its children.
- Limits are enforced by the kernel using rlimits (see `man setrlimit` and `man prlimit`).

## Common checks
- `ulimit -a` shows many limits (units vary).
- `ulimit -Sn` (soft nofile), `ulimit -Hn` (hard nofile)
- `/proc/$$/limits` is the kernel truth for your current shell.
- `prlimit --pid $$` can show and set limits (if installed).

## Recovery
If you set something too low:
- open a new terminal
- or run `bash --noprofile --norc` for a clean shell (still inherits from parent though).

## File descriptor test
- Your shell, terminal, and Python already use some FDs.
- So failing at ~120 when you set 128 is expected.

## CPU time
- CPU time is not wall-clock time.
- A “sleep 5” would not burn CPU; a busy loop does.

## Persistence
If you want a limit to apply at login:
- PAM limits (`/etc/security/limits.conf`) is common for interactive sessions.
- systemd may override for services or user sessions.

Do not edit system files unless you understand them; this sandbox is mostly about **observing**.
