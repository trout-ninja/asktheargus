# Process Troubleshooting Sandbox: top, ps, and /proc

This sandbox gives you controlled, safe processes to inspect with:
- `top` / `htop` (if installed)
- `ps`, `pgrep`, `pkill`, `pstree`
- `/proc/<PID>/...` (status, stat, cmdline, fd, limits, environ)
- basic log sleuthing (sandbox logs + your system logs if available)

## Quick start
1) Unzip and enter the directory
2) Start the lab workload:
   ```bash
   ./tools/start_lab.sh
   ```
3) Do the missions:
   ```bash
   less missions/missions.md
   ```
4) Stop/cleanup:
   ```bash
   ./tools/stop_lab.sh
   ```

## Safety
- Workloads are modest by default.
- All PIDs are recorded in `run/`.
- `stop_lab.sh` only targets PIDs it started.

## Deliverables
Write your answers in:
- `notes/mission1_top.txt`
- `notes/mission2_ps.txt`
- `notes/mission3_proc.txt`
- `notes/mission4_troubleshoot.txt`
- `notes/mission5_logs.txt`
