# Missions — Processes, top/ps, and /proc

## Mission 0 — Setup
Start the controlled workload:
```bash
./tools/start_lab.sh
```
Confirm you have PIDs:
```bash
ls -1 run/*.pid
```

---

## Mission 1 — `top` fundamentals (observation)
1) Run `top`.
2) Identify:
   - the CPU hog process
   - the memory hog process
   - the I/O writer process
3) In `top`, practice:
   - `P` (sort by CPU)
   - `M` (sort by memory)
   - `T` (sort by time)
   - `k` (kill a process — do **not** kill random system processes)
   - `r` (renice)
4) Record:
   - PID, %CPU, %MEM for each lab process
   - what key(s) you used to surface it

**Deliverable:** `notes/mission1_top.txt`

Hints:
- Lab processes have names like `cpu_hog_1`, `mem_hog_1`, `io_writer_1`, `sleeper_1`.
- If `top` shows only `python3`, use `ps` below to map PID → command line.

---

## Mission 2 — `ps` and process discovery
1) List the lab processes in at least two ways:
```bash
ps -eo pid,ppid,ni,stat,etime,pcpu,pmem,cmd | grep -E "cpu_hog|mem_hog|io_writer|sleeper" | grep -v grep
pgrep -af "cpu_hog|mem_hog|io_writer|sleeper"
```
2) Find parent/child relationships:
```bash
ps -o pid,ppid,cmd -p $(cat run/*.pid)
pstree -ap $(cat run/lab_leader.pid) 2>/dev/null || true
```
3) Explain what the STAT column means for at least two processes (example states: R, S, D, Z, T).

**Deliverable:** `notes/mission2_ps.txt`

---

## Mission 3 — `/proc` as ground truth
Pick one PID (CPU hog is best) and inspect:

1) Identity:
```bash
PID=$(cat run/cpu_hog_1.pid)
cat /proc/$PID/cmdline | tr '\0' ' ' ; echo
cat /proc/$PID/status | sed -n '1,30p'
```

2) Limits and environment:
```bash
cat /proc/$PID/limits
tr '\0' '\n' < /proc/$PID/environ | sed -n '1,25p'
```

3) Open files:
```bash
ls -l /proc/$PID/fd | head
```

4) CPU accounting:
```bash
cat /proc/$PID/stat
# Optional: compare to top's TIME+ field.
```

Explain (in plain English) what each file is telling you.

**Deliverable:** `notes/mission3_proc.txt`

---

## Mission 4 — Troubleshooting drills (safe)
### A) Reduce impact without killing
1) Identify the CPU hog PID.
2) Lower its priority (increase NI):
```bash
sudo renice +10 -p $(cat run/cpu_hog_1.pid) || renice +10 -p $(cat run/cpu_hog_1.pid)
```
3) Verify the niceness change in `ps` and observe CPU in `top`.

### B) Stop the right thing, the right way
1) Send SIGTERM to the I/O writer:
```bash
kill $(cat run/io_writer_1.pid)
```
2) Confirm it exits (PID disappears; `ps -p PID` returns nothing).
3) Restart workload component only:
```bash
./tools/start_one.sh io_writer_1
```

Write what you observed and why SIGTERM is preferable to SIGKILL for normal shutdown.

**Deliverable:** `notes/mission4_troubleshoot.txt`

---

## Mission 5 — Logs and correlation
This sandbox includes synthetic logs in `logs/`.

1) Tail the app log while the workload runs:
```bash
tail -f logs/app.log
```

2) Find “ERROR” lines and correlate timestamps with process behavior:
```bash
grep -n "ERROR" logs/app.log | tail
```

3) Optional (system-dependent): look at system logs
- Fedora/Rocky with systemd:
  ```bash
  journalctl -n 50 --no-pager
  journalctl -u atd -n 50 --no-pager 2>/dev/null || true
  ```
- Classic files (may or may not exist):
  ```bash
  ls -la /var/log | head
  ```

Explain:
- what was happening when an ERROR occurred (based on the log message + what you saw in top/ps)
- why logs are often the fastest route to “what changed?”

**Deliverable:** `notes/mission5_logs.txt`

---

## Cleanup
```bash
./tools/stop_lab.sh
```
