#!/usr/bin/env python3
import argparse, os, time, random, pathlib

def log(path: str, level: str, msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"{ts} {level} io_writer: {msg}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--log", required=True)
    args = ap.parse_args()

    outdir = pathlib.Path(args.dir)
    outdir.mkdir(parents=True, exist_ok=True)
    target = outdir / "io_writer.data"

    log(args.log, "INFO", f"starting (pid={os.getpid()}, target={target})")
    n = 0
    while True:
        n += 1
        # Write small chunks and flush to create visible I/O.
        with open(target, "ab", buffering=0) as f:
            payload = os.urandom(8192)
            f.write(payload)
        if n % 50 == 0:
            log(args.log, "INFO", f"wrote {n*8} KB so far")
        if n % 200 == 0:
            # Simulate occasional application errors.
            log(args.log, "ERROR", "simulated write-path warning: transient I/O backlog")
        time.sleep(0.05)

if __name__ == "__main__":
    main()
