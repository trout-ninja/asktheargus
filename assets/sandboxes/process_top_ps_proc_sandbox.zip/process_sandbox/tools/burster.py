#!/usr/bin/env python3
import argparse, os, time, random, subprocess, sys

def log(path: str, level: str, msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"{ts} {level} burster: {msg}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--log", required=True)
    args = ap.parse_args()

    log(args.log, "INFO", f"starting (pid={os.getpid()})")
    while True:
        # Create short-lived subprocesses to practice catching ephemeral PIDs.
        count = random.randint(2, 6)
        procs = []
        for _ in range(count):
            p = subprocess.Popen(["bash", "-lc", "python3 -c 'import time; x=0\nfor i in range(3000000): x+=i\nprint(x)\n' >/dev/null"])
            procs.append(p)
        log(args.log, "INFO", f"spawned {count} short-lived workers")
        for p in procs:
            p.wait()
        time.sleep(random.uniform(0.6, 1.5))

if __name__ == "__main__":
    main()
