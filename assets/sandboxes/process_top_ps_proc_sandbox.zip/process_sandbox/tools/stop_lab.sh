#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="$ROOT_DIR/run"
LOG_DIR="$ROOT_DIR/logs"

if ! compgen -G "$RUN_DIR/*.pid" > /dev/null; then
  echo "No PID files found in $RUN_DIR. Nothing to stop."
  exit 0
fi

echo "Stopping lab processes listed in $RUN_DIR ..."

# Stop non-leader processes first
for pidfile in "$RUN_DIR"/*.pid; do
  name="$(basename "$pidfile" .pid)"
  [[ "$name" == "lab_leader" ]] && continue
  pid="$(cat "$pidfile" || true)"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
    echo " - SIGTERM $name (PID $pid)"
    kill "$pid" 2>/dev/null || true
  fi
done

# Give them a moment to exit cleanly
sleep 1

# Hard kill any survivors (only those we started)
for pidfile in "$RUN_DIR"/*.pid; do
  name="$(basename "$pidfile" .pid)"
  pid="$(cat "$pidfile" || true)"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
    echo " - SIGKILL $name (PID $pid)"
    kill -9 "$pid" 2>/dev/null || true
  fi
done

# Remove pid files
rm -f "$RUN_DIR"/*.pid

echo "Cleanup complete."
echo "Logs remain in: $LOG_DIR"
