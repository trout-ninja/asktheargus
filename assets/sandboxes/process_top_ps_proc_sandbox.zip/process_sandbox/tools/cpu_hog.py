#!/usr/bin/env python3
import argparse, time, os, math, random

def log_line(path: str, msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"{ts} INFO cpu_hog: {msg}\n")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--seconds", type=int, default=60)
    p.add_argument("--log", type=str, required=True)
    args = p.parse_args()

    end = time.time() + args.seconds
    log_line(args.log, f"starting (pid={os.getpid()})")
    x = 0.0
    loops = 0
    # Busy loop with some math so the interpreter can't optimize it away.
    while time.time() < end:
        x = math.sin(x + random.random()) * 0.999999 + 0.000001
        loops += 1
        if loops % 8_000_000 == 0:
            log_line(args.log, f"still busy (loops={loops})")
    log_line(args.log, f"exiting (loops={loops})")

if __name__ == "__main__":
    main()
