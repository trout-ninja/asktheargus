#!/usr/bin/env python3
import argparse, time, os, random

def log(path: str, level: str, msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"{ts} {level} mem_hog: {msg}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mb", type=int, default=150, help="How many MB to allocate and touch.")
    ap.add_argument("--log", required=True)
    args = ap.parse_args()

    log(args.log, "INFO", f"starting (pid={os.getpid()}, mb={args.mb})")
    # Allocate a bytearray and touch it so it is resident.
    size = args.mb * 1024 * 1024
    buf = bytearray(size)
    step = 4096
    for i in range(0, len(buf), step):
        buf[i] = (i // step) % 256

    log(args.log, "INFO", "allocation complete; entering hold loop")
    # Periodically touch pages so it doesn't get swapped as easily.
    while True:
        for _ in range(5000):
            idx = random.randrange(0, len(buf), step)
            buf[idx] ^= 1
        time.sleep(0.2)

if __name__ == "__main__":
    main()
