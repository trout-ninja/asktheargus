#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="$ROOT_DIR/run"
LOG_DIR="$ROOT_DIR/logs"
TOOLS_DIR="$ROOT_DIR/tools"

mkdir -p "$RUN_DIR" "$LOG_DIR"

# If already running, refuse politely.
if compgen -G "$RUN_DIR/*.pid" > /dev/null; then
  echo "It looks like lab PIDs already exist in $RUN_DIR."
  echo "If the lab is not actually running, clean up with: $TOOLS_DIR/stop_lab.sh"
  exit 0
fi

# A tiny "leader" process so pstree has an anchor.
# We use setsid so the leader becomes a session leader and children group nicely.
setsid bash -c 'exec -a lab_leader sleep 1000000' &
echo $! > "$RUN_DIR/lab_leader.pid"

LEADER_PID="$(cat "$RUN_DIR/lab_leader.pid")"

# Helper to start a named background task under the leader's process group.
start_named() {
  local name="$1"
  shift
  # Start as a child of leader via bash -c and set process name via exec -a.
  # We avoid sudo; everything runs as the current user.
  bash -c "exec -a $name $*" </dev/null >>"$LOG_DIR/${name}.out" 2>>"$LOG_DIR/${name}.err" &
  echo $! > "$RUN_DIR/${name}.pid"
}

# CPU hog (spins)
start_named cpu_hog_1 "python3 $ROOT_DIR/tools/cpu_hog.py --seconds 1000000 --log $LOG_DIR/app.log"

# Memory hog (allocates a modest amount and touches it)
start_named mem_hog_1 "python3 $ROOT_DIR/tools/mem_hog.py --mb 220 --log $LOG_DIR/app.log"

# I/O writer (writes/flushes repeatedly to generate small disk activity)
start_named io_writer_1 "python3 $ROOT_DIR/tools/io_writer.py --dir $ROOT_DIR/logs --log $LOG_DIR/app.log"

# Sleeper (mostly idle)
start_named sleeper_1 "bash -c 'while true; do sleep 5; done'"

# A short-lived "bursty" process that comes and goes (useful for ps snapshots)
start_named burster_1 "python3 $ROOT_DIR/tools/burster.py --log $LOG_DIR/app.log"

echo "Lab started."
echo "Leader PID: $LEADER_PID"
echo "PIDs saved under: $RUN_DIR"
echo
echo "Next:"
echo "  less $ROOT_DIR/missions/missions.md"
