#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_DIR="$ROOT_DIR/run"
LOG_DIR="$ROOT_DIR/logs"

name="${1:-}"
if [[ -z "$name" ]]; then
  echo "Usage: $0 <cpu_hog_1|mem_hog_1|io_writer_1|sleeper_1|burster_1>"
  exit 2
fi

if [[ -f "$RUN_DIR/${name}.pid" ]]; then
  pid="$(cat "$RUN_DIR/${name}.pid" || true)"
  if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
    echo "$name already running with PID $pid"
    exit 0
  fi
  rm -f "$RUN_DIR/${name}.pid"
fi

case "$name" in
  cpu_hog_1)
    bash -c "exec -a cpu_hog_1 python3 $ROOT_DIR/tools/cpu_hog.py --seconds 1000000 --log $LOG_DIR/app.log" \
      </dev/null >>"$LOG_DIR/${name}.out" 2>>"$LOG_DIR/${name}.err" &
    ;;
  mem_hog_1)
    bash -c "exec -a mem_hog_1 python3 $ROOT_DIR/tools/mem_hog.py --mb 220 --log $LOG_DIR/app.log" \
      </dev/null >>"$LOG_DIR/${name}.out" 2>>"$LOG_DIR/${name}.err" &
    ;;
  io_writer_1)
    bash -c "exec -a io_writer_1 python3 $ROOT_DIR/tools/io_writer.py --dir $ROOT_DIR/logs --log $LOG_DIR/app.log" \
      </dev/null >>"$LOG_DIR/${name}.out" 2>>"$LOG_DIR/${name}.err" &
    ;;
  sleeper_1)
    bash -c "exec -a sleeper_1 bash -c 'while true; do sleep 5; done'" \
      </dev/null >>"$LOG_DIR/${name}.out" 2>>"$LOG_DIR/${name}.err" &
    ;;
  burster_1)
    bash -c "exec -a burster_1 python3 $ROOT_DIR/tools/burster.py --log $LOG_DIR/app.log" \
      </dev/null >>"$LOG_DIR/${name}.out" 2>>"$LOG_DIR/${name}.err" &
    ;;
  *)
    echo "Unknown component: $name"
    exit 2
    ;;
esac

echo $! > "$RUN_DIR/${name}.pid"
echo "Started $name with PID $(cat "$RUN_DIR/${name}.pid")"
