# Missions — What lives under `/` and why

You will explore a **fake root** first, then compare to your **real system**.

## Mission 1 — Map the root directory (fake root)
Explore:
```bash
cd fake_root
ls -la
tree -L 2 . 2>/dev/null || find . -maxdepth 2 -type d | sort
```

In `notes/mission1_map.txt`, write:
- A short purpose statement for at least 10 top-level directories (e.g., `bin`, `etc`, `usr`, `var`, `home`, `proc`, `sys`, `dev`, `run`, `tmp`).

---

## Mission 2 — “Real vs virtual” directories
In the fake root:
```bash
sed -n '1,80p' proc/README
sed -n '1,80p' sys/README
sed -n '1,80p' dev/README
```

On the real system, inspect:
```bash
mount | egrep ' on /(proc|sys|dev|run) ' || true
ls -la /proc | head
ls -la /sys  | head
ls -la /dev  | head
```

In `notes/mission2_virtual.txt`, explain:
- Why `/proc` and `/sys` are called "virtual" filesystems
- What `/dev` represents
- Why `/run` exists and why it is typically tmpfs

---

## Mission 3 — Configuration vs data: `/etc` vs `/var`
In the fake root:
```bash
sed -n '1,80p' etc/fstab
sed -n '1,80p' etc/passwd
sed -n '1,80p' var/log/messages
```

On the real system:
```bash
ls -la /etc | head
ls -la /var/log | head
```

In `notes/mission3_etc_var.txt`, explain:
- What kinds of things live in `/etc` (and why they are usually text)
- What kinds of things live in `/var` (and why they change frequently)
- Give two examples you saw on your machine

---

## Mission 4 — Programs and libraries: `/bin`, `/sbin`, `/usr/*`
On your real system:
```bash
command -v ls
command -v systemctl
ls -la /bin | head
ls -la /usr/bin | head
ls -la /lib 2>/dev/null | head || true
ls -la /usr/lib | head
```

In `notes/mission4_bins_usr.txt`, explain:
- Why `/usr` is not “user home” (historical meaning)
- The practical difference between `/bin` and `/usr/bin` on modern distros (hint: symlinks/merged-usr)
- What `sbin` is for
- Where shared libraries typically live

---

## Mission 5 — Safety and cleanup directories: `/tmp`, `/var/tmp`, `/opt`, `/srv`, `/mnt`, `/media`
In the fake root:
```bash
ls -la tmp
ls -la var/tmp
```

On the real system:
```bash
ls -ld /tmp /var/tmp
ls -ld /mnt /media /opt /srv 2>/dev/null || true
```

In `notes/mission5_special.txt`, explain:
- `/tmp` vs `/var/tmp` (lifetime expectations)
- When `/opt` is appropriate
- What `/mnt` and `/media` are typically used for
- What `/srv` is intended for

---

## Cleanup
This lab is read-only. No cleanup needed.
