# Root Directory Cheatsheet

- `/bin`  : essential user commands (often symlinked to `/usr/bin` today)
- `/sbin` : essential admin/system commands (often symlinked to `/usr/sbin`)
- `/etc`  : system-wide configuration (text configs)
- `/home` : user home directories
- `/root` : root user's home directory
- `/usr`  : userland programs, libraries, shareable data (historical: "Unix System Resources")
- `/var`  : variable data (logs, spool, cache, databases)
- `/tmp`  : temporary files (often cleared on reboot)
- `/var/tmp` : temp files that may persist longer than `/tmp`
- `/run`  : runtime state (PIDs, sockets), usually tmpfs
- `/dev`  : device nodes
- `/proc` : process and kernel info (virtual)
- `/sys`  : kernel device model and settings (virtual)
- `/boot` : kernel + bootloader artifacts
- `/opt`  : optional third-party apps
- `/mnt`  : temporary mounts by admins
- `/media`: removable media mounts
- `/srv`  : data served by services (web/ftp/etc)
