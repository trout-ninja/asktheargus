#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FAKE="$ROOT_DIR/fake_root"

say() { printf "\n%s\n" "$1"; }
wait_key() { read -r -p "Press Enter to continue..." _; }

say "Linux Root Directory Guide"
say "We will tour a SAFE fake root first: $FAKE"
wait_key

cd "$FAKE"
say "Top-level directories (fake root):"
ls -la
wait_key

say "1) Configuration lives in /etc"
ls -la etc
say "Open etc/fstab and etc/passwd to see examples."
wait_key

say "2) Variable data lives in /var (logs, caches, state)"
ls -la var
say "Peek at var/log/messages"
sed -n '1,20p' var/log/messages
wait_key

say "3) Virtual filesystems: /proc and /sys"
say "These are views into kernel state, not real files on disk."
sed -n '1,5p' proc/README
sed -n '1,5p' sys/README
wait_key

say "4) Device nodes: /dev"
sed -n '1,5p' dev/README
wait_key

say "5) Programs: /bin and /usr/bin"
say "Modern distros often 'merge' these, but historically /bin was essential binaries."
ls -la bin | head
ls -la usr/bin | head
wait_key

say "Next step: open missions and complete the writeups."
say "  less $ROOT_DIR/missions/missions.md"
