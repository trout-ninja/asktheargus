# Sandbox: Exploring the Linux Root Directory (`/`)

This sandbox teaches **what lives under `/` and why**, safely.
You will explore a **fake root filesystem** (included) and then compare it to your real system.

Nothing here modifies your actual `/`.

## Start
1) Unzip and enter the folder
2) Read missions:
   ```bash
   less missions/missions.md
   ```
3) Optional interactive guide:
   ```bash
   ./tools/dir_guide.sh
   ```

## Deliverables
Write answers into `notes/` as directed.
