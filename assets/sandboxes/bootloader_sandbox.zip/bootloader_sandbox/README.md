# Bootloader Process Interactive Sandbox

This sandbox teaches the Linux boot process *without touching your real bootloader*.
You will explore a **simulated boot pipeline** that mirrors reality:

  Firmware → Bootloader → Kernel → init/systemd → userspace

Everything here is safe, reversible, and inspectable.

## Start here
```bash
./tools/boot_simulator.sh
```

## What you will learn
- What the bootloader does (and does *not* do)
- Where GRUB fits
- How the kernel hands off to init/systemd
- How boot logs are structured
- How to reason about boot failures

## Deliverables
Write answers into `notes/` as directed in `missions/`.
