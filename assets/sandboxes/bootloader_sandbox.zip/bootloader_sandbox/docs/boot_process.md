# Real Linux Boot Process (Reference)

1. Firmware (BIOS/UEFI)
2. Bootloader (GRUB)
3. Kernel
4. initramfs
5. init/systemd (PID 1)
6. Userspace services and login

The bootloader:
- Selects kernel
- Passes kernel parameters
- Loads initramfs
- Does NOT start services
- Does NOT manage processes
