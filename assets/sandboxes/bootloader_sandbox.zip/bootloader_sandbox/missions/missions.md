# Missions — Bootloader & Boot Process

## Mission 1 — Trace the boot chain
Run the simulator:
```bash
./tools/boot_simulator.sh
```

Answer in `notes/mission1_chain.txt`:
- List the boot stages in order
- Identify where the bootloader stops and the kernel begins

---

## Mission 2 — Inspect boot artifacts
Examine simulated boot files:
```bash
tree run/
cat run/grub.cfg
cat run/cmdline
```

Answer in `notes/mission2_artifacts.txt`:
- What information does the bootloader pass to the kernel?
- What does it *not* control?

---

## Mission 3 — Simulated failure
Re-run with a failure injected:
```bash
./tools/boot_simulator.sh --fail kernel
```

Answer in `notes/mission3_failure.txt`:
- What failed?
- What stage could realistically fix this?

---

## Mission 4 — Logs & handoff
Inspect logs:
```bash
less run/boot.log
```

Answer in `notes/mission4_logs.txt`:
- Where does the bootloader stop logging?
- Which component logs next?

---

## Mission 5 — Compare to real system
On your real system, inspect:
```bash
journalctl -b | head
```

Answer in `notes/mission5_compare.txt`:
- What similarities exist between the simulator and reality?
