#!/usr/bin/env bash
set -e

FAIL_STAGE=""

if [[ "$1" == "--fail" ]]; then
    FAIL_STAGE="$2"
fi

RUN_DIR="run"
LOG="$RUN_DIR/boot.log"

rm -rf "$RUN_DIR"
mkdir -p "$RUN_DIR"
: > "$LOG"

log() {
    echo "[$(date +%H:%M:%S)] $1" | tee -a "$LOG"
    sleep 0.5
}

log "Firmware (BIOS/UEFI): hardware init complete"

log "Bootloader (GRUB): loading configuration"
cat <<EOF > "$RUN_DIR/grub.cfg"
set default=0
set timeout=5
linux /vmlinuz root=/dev/sda1 ro quiet
initrd /initramfs.img
EOF

if [[ "$FAIL_STAGE" == "bootloader" ]]; then
    log "Bootloader ERROR: cannot load kernel"
    exit 1
fi

log "Bootloader: loading kernel and initramfs"
echo "root=/dev/sda1 ro quiet" > "$RUN_DIR/cmdline"

log "Kernel: decompression and early init"
if [[ "$FAIL_STAGE" == "kernel" ]]; then
    log "Kernel PANIC: unable to mount root fs"
    exit 1
fi

log "Kernel: starting init process (PID 1)"

log "init/systemd: mounting filesystems"
log "init/systemd: starting services"

log "Userspace: login prompt ready"

echo
echo "Boot simulation complete."
